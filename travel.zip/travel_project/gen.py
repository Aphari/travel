import os
import json

# Create the travel_agadir directory if it doesn't exist
if not os.path.exists('travel_agadir'):
    os.makedirs('travel_agadir')

# Create the app.py file
with open('travel_agadir/app.py', 'w') as f:
    f.write('# This is an example app\n')
    f.write('print("Hello, Agadir!")\n')

# Create the static directory and its contents
static_dir = 'travel_agadir/static'
if not os.path.exists(static_dir):
    os.makedirs(static_dir)

css_dir = os.path.join(static_dir, 'css')
if not os.path.exists(css_dir):
    os.makedirs(css_dir)

with open(os.path.join(css_dir, 'styles.css'), 'w') as f:
    f.write('body { background-color: #f2f2f2; }\n')

images_dir = os.path.join(static_dir, 'images')
if not os.path.exists(images_dir):
    os.makedirs(images_dir)

# Create the images directory with some example images
for i in range(10):
    filename = f'destination_{i}.jpg'
    with open(os.path.join(images_dir, filename), 'wb') as f:
        f.write(b'\x00' * 1000)  # Replace with actual image data

# Create the templates directory and its contents
templates_dir = 'travel_agadir/templates'
if not os.path.exists(templates_dir):
    os.makedirs(templates_dir)

base_template = 'travel_agadir/templates/base.html'
with open(base_template, 'w') as f:
    f.write('<html><body>{% block content %}{% endblock %}</body></html>\n')

index_template = 'travel_agadir/templates/index.html'
with open(index_template, 'w') as f:
    f.write('<html><body>This is the index page</body></html>\n')

path_template = 'travel_agadir/templates/path.html'
with open(path_template, 'w') as f:
    f.write('<html><body>This is a path page</body></html>\n')

# Create the data directory and its contents
data_dir = 'travel_agadir/data'
if not os.path.exists(data_dir):
    os.makedirs(data_dir)

paths_json = 'travel_agadir/data/paths.json'
with open(paths_json, 'w') as f:
    json.dump({'paths': [{'name': 'Path 1', 'distance': 5}, {'name': 'Path 2', 'distance': 10}]}, f)
