from flask import Flask, render_template, url_for, jsonify
import json

app = Flask(__name__)

# Load paths data
with open('data/paths.json', 'r') as file:
    paths = json.load(file)

@app.route('/')
def home():
    return render_template('index.html', paths=paths)

@app.route('/path/<int:path_id>')
def path_detail(path_id):
    path = next((p for p in paths if p['id'] == path_id), None)
    if path:
        return render_template('path.html', path=path)
    return "Path not found", 404

if __name__ == '__main__':
    app.run(debug=True)
